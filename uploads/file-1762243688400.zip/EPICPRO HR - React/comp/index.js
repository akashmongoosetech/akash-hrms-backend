import React, { Component } from 'react';

export default class index extends Component {
	render() {
		return <p>Hello Hello!</p>;
	}
}
